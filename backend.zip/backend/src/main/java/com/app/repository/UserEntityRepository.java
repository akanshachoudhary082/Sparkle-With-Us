package com.app.repository;

public class UserEntityRepository {

}
