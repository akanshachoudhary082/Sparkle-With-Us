package com.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.entities.Login;
import com.app.repository.LoginRepository;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {
	@Autowired
    private LoginRepository loginRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public boolean loginUser(String username, String password) {
        Login login = loginRepository.findByUsername(username);
        if (login != null) {
            return passwordEncoder.matches(password, login.getPassword());
        }
        return false;
    }
    
    @Override
    public void registerUser(String username, String password) {
        Login login = new Login();
        login.setUsername(username);
        login.setPassword(passwordEncoder.encode(password));
        loginRepository.save(login);
    }
    
    @Override
    public Login getUserByUsername(String username) {
        return loginRepository.findByUsername(username);
    }
    
    @Override
    public void updatePassword(String username, String oldPassword, String newPassword) {
        Login login = loginRepository.findByUsername(username);
        if (login != null) {
            if (passwordEncoder.matches(oldPassword, login.getPassword())) {
                login.setPassword(passwordEncoder.encode(newPassword));
                loginRepository.save(login);
            } else {
                throw new RuntimeException("Old password does not match");
            }
        } else {
            throw new RuntimeException("User not found");
        }
    }
    
    @Override
    public void deleteUser(String username) {
        Login login = loginRepository.findByUsername(username);
        if (login != null) {
            loginRepository.delete(login);
        } else {
            throw new RuntimeException("User not found");
        }
    }
    @Override
    public boolean userExists(String username) {
        return loginRepository.existsByUsername(username);
    }
}
