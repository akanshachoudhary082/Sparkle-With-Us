package com.app.service;

public interface LoginService {
	boolean login(String username, String password);

	boolean register(String username, String password);

	boolean userExists(String username);

	boolean changePassword(String username, String oldPassword, String newPassword);

	boolean resetPassword(String username);
}
