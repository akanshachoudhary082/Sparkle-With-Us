package com.app.entities;

public enum PaymentStatus {

	CONFIRMED,CANCELLED;
}
