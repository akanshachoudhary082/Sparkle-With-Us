package com.app.entities;

public enum Specialization 
{
	HAIRCUTS, COLOURIST, WAXING_SPECIALIST, MAKEUP_ARTIST;
}
