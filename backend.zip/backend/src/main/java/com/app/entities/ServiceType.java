package com.app.entities;

public enum ServiceType 
{
	NAIL_SERVICES, SKIN_CARE, HAIR_TREATMENTS, HAIR_SERVICES, SPA_SERVICES, MAKEUP, GROOMING
}
