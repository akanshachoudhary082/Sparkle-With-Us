package com.app.security;

public class CustomUserDetailsService {

}
